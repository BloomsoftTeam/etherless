exports.handler = async (e) => {

  let inputBoard = [];
  //let inputBoard = ["090042136", "000960485", "000581000", "004000000", "517200900", "602000370", "100804020", "706000810", "300090000"];
  e.params.forEach((element) => {
    inputBoard.push(element);
  })

  // console.log(inputBoard);

  let board = [];
  inputBoard.forEach((element) => {
    let substituteArray = [];
    for(let i = 0; i < element.length; i++){
      substituteArray.push(element.substring(i, i+1));
    }
    board.push(substituteArray);
  });
  // console.log(board);
  sodokoSolver(board);
  // console.log(board);
  let result = '';

  let counter = 1;
  board.forEach((item) => {
      let riga = ' ';
      item.forEach((element)=>{
          riga+=`${element} `;
      })
      result += `riga${counter} = ${riga}     `;
      counter++;
  });
  const response = {
    statusCode: 200,
    body: result
  }
  // console.log(response);
  return response;

  function isValid(board, row, col, k) {
    for (let i = 0; i < 9; i++) {
        const m = 3 * Math.floor(row / 3) + Math.floor(i / 3);
        const n = 3 * Math.floor(col / 3) + i % 3;
        if (board[row][i] == k || board[i][col] == k || board[m][n] == k) {
          return false;
        }
    }
    return true;
  }


  function sodokoSolver(data) {
    for (let i = 0; i < 9; i++) {
      for (let j = 0; j < 9; j++) {
        if (data[i][j] == '0') {
          for (let k = 1; k <= 9; k++) {
            if (isValid(data, i, j, k)) {
              data[i][j] = `${k}`;
            if (sodokoSolver(data)) {
            return true;
            } else {
            data[i][j] = '0';
            }
          }
        }
        return false;
      }
    }
  }
  return true;
  }
};