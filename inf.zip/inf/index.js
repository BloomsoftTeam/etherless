exports.handler = async (e) => {
  let a = 0;
  while(true){
    a = a + 1;
  }
  
  const response = {
      statusCode: 200,
      body: JSON.stringify({'sum': sum}),
  };
  return response;
};
