const https = require('https');

exports.handler = async (e) => {
    const paramNumber = parseInt(e.params[0]);
    const initialCurrency = e.params[1];
    const returnCurrency = e.params[2];
    let finalResult = '';
    const response = await new Promise((resolve, reject) => { 
        const req = https.get(`https://${returnCurrency}.rate.sx/${paramNumber}${initialCurrency}`, (res) => {
            res.on('data', chunk => {
                finalResult += chunk;
                finalResult = finalResult.substring(0, finalResult.length-1);
            });
            res.on('end', () => {
                resolve({
                    statusCode: 200,
                    body: `Your requested conversion of ${paramNumber} ${initialCurrency} is ${finalResult} ${returnCurrency}.`
                });
            });
            req.on('error', (e) => {
                reject({
                    statusCode: 500,
                    body: 'Something went wrong!'
                });
            });
        });    
    }); 
    return response;   
};