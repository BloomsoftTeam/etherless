exports.handler = async (event) => {
  // TODO implement
  
  const num1 = 5;
  const num2 = 5;
  const sum = num1 + num2;
  
  const response = {
      statusCode: 200,
      body: JSON.stringify({'sum': sum}),
  };
  return response;
};
